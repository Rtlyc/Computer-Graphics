This is the HW2 for Computer Graphics. In this hw, I implemented a rotating sphere on the ground with customized viewpoints. 

Building Instructions:
(a) $mkdir build # create a build folder and build the program 
(b) $cd build 
(c) $cmake .. 
(d) $make 
(e) $./RotateBall


Here are operation instructions:
'x' or 'X': adjust x-axis for the camera
'y' or 'Y': adjust y-axis for the camera
'z' or 'Z': adjust z-axis for the camera
'b' or 'B': start rolling
left mouse button: Menu Popup
right mouse button: control animation